# Multion Python SDK

The Multion Python SDK provides a convenient way to interact with the Multion API and perform various operations such as creating sessions, updating sessions, closing sessions, and retrieving session information.

## Documentation

For detailed documentation on how to use the Multion Python SDK and the available functions, please refer to the official Multion API [documentation](https://docs.multion.ai).
